<head>
  <!-- Site made with Mobirise Website Builder v3.12.1, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v3.12.1, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="assets/images/logo.png" type="image/x-icon">
  <meta name="description" content="Website Builder Description">
  <title>Login</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic&amp;subset=latin">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,700">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
  <link rel="stylesheet" href="assets/bootstrap-material-design-font/css/material.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise3-blocks-plugin/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Noto+Serif" rel="stylesheet">
</head>

<body>

<section class="engine"><a rel="external" href="#"></a>
</section>

<section id="menu-1">
<nav class="navbar navbar-dropdown navbar-fixed-top">
<div class="container">
<div class="mbr-table">
<div class="mbr-table-cell">
<div class="navbar-brand">
<div class="nav-item nav-btn"><a a class="nav-link btn btn-light-outline btn-black" href="interact.php">view&interact</a></div>
</div>
</div> <!-- this closes the first cell -->
</div>
</div>
</nav>
</section>


<section class="mbr-section mbr-section-hero mbr-section-full extHeader15 mbr-after-navbar" id="extHeader15-d" style="background-image: url(assets/images/about.jng);">

    <div class="mbr-overlay" style="opacity: 0.6; background-color: #000000">  <!-- this is where I have made the color to be black --></div>
        <div class="mbr-table-cell">
            <div class="container">

              <div id="title">
                <div class="mbr-figure image-size" style="width: 5%; font-size: 20px;">
                    <span class="mbri-features mbr-iconfont mbr-iconfont-features4" style="font-size: 80px; color: rgb(255, 255, 255);"></span></div>
                  <div class="span-title">
                      <div class="span-title">
                        <span class="mbr-section-title display-3 text-center pad-r">OUR NARRATIVES ABOUT </span>
                        <span class="mbr-section-title display-3 element typedextHeader15-d" adress="typedextHeader15-d" firstel="FEES IN HIGHER EDUCATION" secondel="OUTBREAK OF BIRD FLU" thirdel="LOCAL FRISBEE SCORES " typespeed="90"></span><br>
                        <span class="mbr-section-title display-3 text-center pad-r">IS CURRENTLY NOT AVAILABLE!</span>
                      </div>
                  </div>
                  <div class="mbr-section-text lead text-center">
                      <p><span style="font-style: normal;">We are sorry about this. Please check again in ...</span></p>
                  </div>

                  <div class="countdown" style="font-style: small;" data-end="2017/07/30"></div>
              </div>
            </div>
        </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smooth-scroll/smooth-scroll.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touch-swipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/typed/typed.min.js"></script>
  <script src="assets/countdown/jquery.countdown.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/mobirise3-blocks-plugin/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
</body>
